from .axolotl_rs import *

__doc__ = axolotl_rs.__doc__
if hasattr(axolotl_rs, "__all__"):
    __all__ = axolotl_rs.__all__